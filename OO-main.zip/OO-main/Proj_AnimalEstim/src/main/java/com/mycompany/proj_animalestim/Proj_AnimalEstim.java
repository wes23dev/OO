/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proj_animalestim;

/**
 *
 * @author 14626232639
 */
public class Proj_AnimalEstim {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
